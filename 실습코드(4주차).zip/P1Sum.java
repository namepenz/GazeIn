package practice;

public class P1Sum {

    /**
     * O(1) 시간 복잡도를 가지는 메소드 구현 
     * 메소드는 1부터 n까지의 합을 반환 
     * 수학적 공식을 활용하여 구현
     * 
     * @param n 입력값
     * @return 1부터 n까지의 합
     */
    public static long sumO1(int n) {
	// 여기에 코드 작성

    }
    
    /**
     * O(n) 시간 복잡도를 가지는 메소드
     * 메소드는 1부터 n까지의 합을 반환
     * 단순 반복문을 사용하여 합을 계산
     * 
     * @param n 입력값
     * @return 1부터 n까지의 합
     */
    public static long sumOn(int n) {
	// 여기에 코드 작성
    }
    
    /**
     * O(n^2) 시간 복잡도를 가지는 메소드를 구현
     * 메소드는 1부터 n까지의 합을 반환
     * 중첩 반복문을 사용하여 각 숫자를 1부터 i까지 더하는 방식으로 합을 계산
     * 
     * @param n 입력값
     * @return 1부터 n까지의 합
     */
    public static long sumOn2(int n) {
	// 여기에 코드 작성
    }
    
    public static void main(String[] args) {

	// 테스트 코드
	int n = 10;
	long startTime, endTime;

	// O(n) 시간 복잡도 메소드 실행 시간 측정
	// 여기에 코드 작성

	// O(n^2) 시간 복잡도 메소드 실행 시간 측정
	// 여기에 코드 작성

	// O(1) 시간 복잡도 메소드 실행 시간 측정
	// 여기에 코드 작성
    }

}
