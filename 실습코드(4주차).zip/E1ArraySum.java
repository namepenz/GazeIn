package practice;

public class E1ArraySum {
    /**
     * 반복문을 사용하여 배열의 모든 원소의 합을 구함
     * 배열을 한 번 순회하면서, 각 원소의 값을 누적하여 합을 구함
     * 
     * @param arr 정수 배열
     * @return 모든 요소의 합
     */
    public static int sumWithLoop(int[] arr) {
        // 여기에 코드를 작성
    }

    /**
     * 재귀를 사용하여 배열의 모든 원소의 합을 구함
     * 
     * @param arr 정수 배열
     * @param index 현재 요소의 인덱스
     * @return 모든 요소의 합
     */
    public static int sumWithRecursion(int[] arr, int index) {
        // 여기에 코드를 작성
    }

    /**
     * 배열을 분할 정복하는 방식으로 모든 원소의 합을 구함
     * 배열을 반으로 나누고, 각 부분의 합을 재귀적으로 계산한 다음, 두 합을 구함
     * 
     * @param arr 정수 배열
     * @param start 시작 인덱스
     * @param end 끝 인덱스
     * @return 모든 요소의 합
     */
    public static int sumWithDivideAndConquer(int[] arr, int start, int end) {
        // 여기에 코드를 작성
	// 시작 인덱스와 끝 인덱스가 같으면(= 나눈 배열의 크기가 1이면) 해당 원소를 반환
	
	// 중간 지점 mid를 계산
	
	// mid를 기준으로 왼쪽 부분의 합을 변수로 지정
	
	// mid를 기준으로 오른쪽 부분의 합을 변수로 지정
	
	// 왼쪽 합과 오른쪽 합을 더하여 반환
	
    }

    public static void main(String[] args) {
        // 테스트 코드
        int[] nums = {1, 2, 4, 8, 16};
        System.out.println("반복문 사용: " + sumWithLoop(nums));
        System.out.println("재귀 사용: " + sumWithRecursion(nums, 0));
        System.out.println("분할 정복 사용: " + sumWithDivideAndConquer(nums, 0, nums.length - 1));
    }
}
